================================================================================
  Network Inspection System V3 — 网络巡检 + 流量测试（个人版 / For Yata）
================================================================================

【概述 / Overview】
  个人专用合并版：V2 巡检功能 + test_A 流量压测功能，一个 exe 搞定。
  巡检：通过 SSH 连接 Linux / Cisco / Huawei 设备，自动执行巡检命令，
        支持异常检测、配置备份、报告导出、连接信息管理。
  压测：内置 UDP / TCP / TCP-SYN 大并发流量发生器 + TCP 接收端。

  运行方式 / Run:
    方法1: 双击 dist/巡检Network Inspection System V3 - For Yata.exe
           (独立exe，无需Python环境)
    方法2: python net_inspect_gui.py          (命令行直接运行，需 paramiko)

  依赖: pip install paramiko
  可选: pip install openpyxl  (Excel 报告导出)

  ⚠️ 注意：本版本含流量压测功能，仅限个人使用，不要分发给同事！
    给同事请用 V2 (巡检Network Inspection System V2 - For GCC.exe)。

================================================================================
【文件说明 / Files】
================================================================================

  文件                                    说明
  ─────────────────────────────────────  ──────────────────────────────────
  net_inspect_gui.py                      主程序（含流量测试核心，V3）
  dist/巡检Network Inspection System V3 - For Yata.exe   独立可执行文件
  dist/巡检Network Inspection System V2 - For GCC.exe    同事版（无压测）
  NetworkInspectionV3.spec                V3 打包配置
  devices.txt                             设备列表文件（批量巡检/备份时读取）
  profiles.json                           保存的常用连接信息
  presets.json                            保存的巡检预设命令集
  backups/                                配置备份存放目录（自动创建）
  reports/                                HTML/CSV 报告存放目录（自动创建）
  app_icon.ico                            V3 程序图标（NIS 蓝）

================================================================================
【功能列表 / Features】
================================================================================

  巡检部分（与 V2 相同）:
    1. 单机巡检       Single Host      — SSH 连接单台设备，可编辑命令集
    2. 批量巡检       Batch Inspect    — 并行多线程 + 异常检测 + 报告导出
    3. 配置备份       Config Backup    — 备份 running-config / current-config
    4. 连接信息管理   Profiles         — profiles.json 保存常用连接
    5. 异常检测       Anomaly Detect   — CPU/内存/磁盘超阈值标红告警
    6. 紧凑输出       Compact Output   — 仅保留关键指标行
    7. 简短巡检       Quick Inspect    — 仅 cpu/mem/alarm/device/stack
    8. 运行状态栏     Status Column    — 批量巡检实时显示 Running/OK/FAILED
    9. Ping 预检      Pre-check        — SSH 前先 ping，不可达直接跳过
   10. 键盘快捷键     Shortcuts        — Enter 启动 / Esc 停止 / Ctrl+Enter
   11. 输出区搜索     Output Search    — 关键词高亮，↑↓ 跳转匹配项
   12. 巡检预设方案   Presets          — 保存/加载自定义命令集
   13. 告警统计       Alarm Stats      — 按设备统计异常行数
   14. 下一异常跳转   Next Anomaly     — ⚠ 按钮循环跳转标红位置

  流量测试部分（V3 新增）:
   15. 流量压测       Traffic Test     — UDP / TCP / TCP-SYN 三种模式
   16. TCP 接收端     TCP Receiver     — 内置服务器，配合 TCP 压测对账
   17. 多端口语法     Port Syntax      — 单口/列表/范围/随机采样
   18. 实时统计       Real-time Stats  — PPS / 带宽 / 总量 / 时长
   19. 网关探测       Gateway Detect   — 自动发现默认网关填入目标 IP

  安全增强（V3.1 新增）:
   20. 攻击日志检测   Attack Scan      — 巡检日志自动识别攻击特征并标红
   21. IP 情报查询    IP Intel         — 公网 IP 一键查 GeoIP/ASN/威胁特征

================================================================================
【键盘快捷键 / Keyboard Shortcuts】
================================================================================

  快捷键             作用
  ────────────────   ──────────────────────────────────────────
  Enter              在 Single Host 输入框中按 → 启动单机巡检
  Ctrl+Enter         全局 → 根据当前标签页启动对应操作
  Esc                全局 → 停止所有正在执行的任务

================================================================================
【标签页一~四：巡检部分（同 V2，简述）】
================================================================================

一、Single Host (单机巡检)
  ────────────────────────
  复选框:
    Anomaly Detection / Compact Output / Quick Inspection / Pre-check (ping)
  操作步骤:
    1. 顶部 "Load Profile" 下拉框选择已保存的连接信息（可选）
    2. 选择设备类型 (Linux Server / Cisco Device / Huawei Device)
    3. 输入 IP、端口、用户名、密码（任一输入框按 Enter 直接启动）
    4. 命令编辑区可增删改命令，格式: 标题::命令
    5. 点击 "Start Inspection" 或按 Enter，随时 "Stop" 或 Esc 中断

二、Batch Inspection (批量巡检)
  ─────────────────────────────
  设备文件格式 (devices.txt):
    IP:用户名:密码:[linux|cisco|huawei]:"命令1,命令2,..."
    type 可选，默认 cisco。支持 # 注释和空行。
  操作步骤:
    1. 选择设备文件 → Load（或 Browse... 选择其他）
    2. 勾选要巡检的设备（不选默认全部）
    3. 设置并发数 Parallel (1~10)，建议 3~5
    4. 点击 "Run"，Status 列实时显示 (--- → Running... → OK / FAILED / WARNING)
    5. 完成后 "Export HTML" / "Export CSV" 导出报告
    6. 按设备异常统计：完成后自动汇总每个 IP 的异常行数

三、Config Backup (配置备份)
  ──────────────────────────
  备份 running-config / current-configuration（Linux 不参与）。
  存储: backups/<类型>/<IP>/<IP>_<日期时间>.cfg

四、Profiles (连接信息管理)
  ─────────────────────────
  保存常用设备连接，Single Host 页 "Load Profile" 快速加载。
  数据文件: profiles.json（明文存储密码，请注意安全）

================================================================================
【标签页五：Traffic Test（流量测试，V3 新增）】
================================================================================

  用途：对网关/服务器做高并发流量压测，验证吞吐能力和稳定性。
        目标 IP 默认 127.0.0.1，可点 "Detect" 自动发现默认网关填入。

  一、Target Configuration（目标配置）
    Target IP    目标 IP
    Port         端口，支持多端口语法（见下表）
    Protocol     UDP / TCP / TCP SYN 三种模式
    Detect       自动探测本机默认网关

    端口语法 / Port Syntax:
      8080               单端口
      80,443,8080        逗号列表（随机选）
      100-1000           范围（随机选）
      100-1000:50        范围内随机采样 50 个端口

  二、Built-in TCP Receiver（内置 TCP 接收端）
    压测 TCP 模式前先启动它，作为对端接收流量并统计 Rx。
    Listen Port 填监听端口 → Start Server → 再回上方填同端口 Start 压测。
    停止压测后点 Stop Server，日志会汇总总接收字节数。

  三、Traffic Parameters（流量参数）
    Concurrency    并发线程数 1~500（压测远程网关建议 100+）
    Packet Size    包大小 64 / 256 / 512 / 1024 / 1460 或自定义（1~65535）
    Rate           每线程发包速率 0~50000 pkt/s

    ⚠️ rate = 0 = 不限速全速发包！
       单线程即可吃满一个 CPU 核心（约 9 万 pkt/s），
       不要在本机/环回上开 0 + 高并发，会把电脑卡死。
       界面会红字警告，切勿无视。

  四、Real-time Statistics（实时统计）
    PPS / Bandwidth (Mbps) / Total Packets / Total Bytes / Elapsed

  五、协议模式说明
    UDP      无连接，直接发数据报，无需服务器（最常用）
    ICMP     ICMP echo flood（ping 洪水），无需服务器；Windows 需管理员权限
    TCP      全连接，需要对端 TCP 服务（配合内置接收端），断线自动重连
    TCP SYN  半开连接（非阻塞 connect 即关），测试网关 TCP 栈，
             不需要服务器，但会被部分防火墙识别为 SYN 扫描

  注: 想测 QUIC 流量压制 → 选 UDP、端口填 443 即可（QUIC 底层就是 UDP，
      网关/防火墙看到 UDP 443 就会按 QUIC 特征处理）。

  操作步骤（UDP 快速上手）:
    1. Target IP 填目标，Port 填 8080
    2. Protocol 选 UDP，Concurrency 10，Packet Size 1024，Rate 1000
    3. 点 Start → 观察实时统计 → 点 Stop 结束，日志输出平均 PPS/Mbps

  注意事项:
    - 请确保在授权范围内使用，不要对未授权的系统发起测试
    - 超高并发可能触发操作系统端口耗尽或防火墙限制
    - 目标服务器需要有足够的处理能力，否则可能导致服务不可用

================================================================================
【安全增强（V3.1）：攻击日志检测 + IP 情报查询】
================================================================================

  一、攻击日志检测（Attack Scan，自动触发）
  ────────────────────────────────────────
  巡检输出只要是"日志类"内容（华为 Logbuffer / Linux auth、secure /
  Web access 日志 / syslog），会自动叠加攻击特征扫描，命中行标红，
  区块末尾追加 🛡 攻击检测 摘要。

  检测类型（10 条规则，纯本地正则，不联网）:
    🔴 Critical/High:
      SSH 认证失败 → 同源 ≥8 次聚合为 "SSH 暴力破解(疑似)"
      命令注入尝试 / WebShell 上传 / SQL 注入 / 路径穿越
      设备安全事件（%SEC/ 日志、attack detected、brute-force）
    🟡 Medium/Low:
      XSS 尝试 / 扫描器指纹（sqlmap/nikto/nmap...）/ 异常 User-Agent
      Web 状态码聚合: 同源 401/403 ≥15 次 → "Web 暴力破解/撞库(疑似)"
                     同源 404 ≥30 次 → "目录扫描(疑似)"

  防误报设计:
    - web 规则只扫 web 请求行、ssh 规则只扫 ssh/syslog 行（类型门控）
    - 区块分隔线（--- [Device] ---）自动跳过
    - info 级别事件（SSH 登录成功）不标色，避免正常登录刷屏
    普通配置输出（display current-configuration 等）不会触发。

  二、IP 情报查询（IP Intel 按钮）
  ────────────────────────────────────────
  位置: Single Host 页右上 + Batch 页工具栏
  功能: 查询公网 IP 的被动情报（ip-api.com 免费接口，无需 Key）:
        国家/地区/城市 · ISP · Org · ASN · 经纬度
        特征标记: 🕶 代理 / ☁ 云主机托管 / 📱 移动网络
  说明:
    - 单机页点击时自动带入当前输入的 IP
    - 内网/保留地址直接提示"无需查询"
    - 需要联网；离线时显示"查询失败（检查网络）"
    - 免费接口限速 45 次/分钟，不要高频连点

================================================================================
【异常检测规则 / Anomaly Rules】
================================================================================

  设备类型    检测指标                阈值      来源
  ────────    ───────────────        ────      ────────────
  Linux       CPU Load (5min)        > 4.0     uptime
  Linux       Disk Usage             > 80%     df -h
  Cisco       CPU 5sec Utilization   > 80%     show processes cpu sorted
  Huawei      CPU Usage              > 80%     display cpu-usage
  Huawei      Memory Usage           > 80%     display memory-usage

  异常信息在输出区颜色高亮（红=Critical / 橙=Major / 黄=Minor+Warning），
  并计入 HTML/CSV 报告。

================================================================================
【默认命令集 / Default Commands】
================================================================================

  Linux Server: Hostname, OS Release, Kernel, Uptime, CPU Info, CPU Cores,
                CPU Load, Memory, Swap, Disk Usage, Top 10 CPU, Top 10 Memory
  Cisco Device: Show Version, Running Config, IP Interface Brief, Interfaces
                Status, VLAN Brief, MAC Address Table, CPU Usage, Memory,
                Logging, Environment
  Huawei Device: Display Version, Current Config, IP Interface Brief,
                Interface Brief, VLAN, MAC Address, CPU Usage, Memory,
                Logbuffer, Environment

================================================================================
【常见问题 / FAQ】
================================================================================

  巡检部分:
  Q: 连接失败？
  A: 检查 IP/端口/用户名/密码；确认目标设备 SSH 服务开启、防火墙放行。

  Q: 华为设备报 "SSH session not active" 错误？
  A: 已修复。对 Cisco/Huawei 使用 invoke_shell() 交互式通道。

  Q: 网络设备输出被截断/分页卡住？
  A: 程序自动发送禁用分页命令
     (Cisco: terminal length 0, Huawei: screen-length 0 temporary)。

  流量测试部分:
  Q: TCP 模式发不出去，日志提示 connect refused？
  A: TCP 需要对端在监听——先在本页启动 Built-in TCP Receiver
     （端口填一样的），再 Start 压测。

  Q: rate 设 0 会怎样？
  A: 不限速全速发包，CPU 会飙升（单线程约 90%），本机测试慎用。

  Q: TCP 接收端显示的包数和发送端对不上？
  A: 正常。TCP 是流协议，接收端按 recv() 次数统计（可能合并包），
     字节数是精确的；看带宽请以字节数/Mbps 为准。

  Q: TCP SYN 模式会被当成攻击吗？
  A: 半开连接特征与 SYN 扫描相似，仅限授权环境使用。

  安全增强部分:
  Q: 攻击检测会不会误报？
  A: 已做类型门控（web 规则只扫 web 行、ssh 规则只扫 ssh 行）+ 跳过分隔线，
     普通配置输出不会触发。若仍有误报，可在 net_inspect_gui.py 的
     _ATTACK_RULES 里调整对应正则。

  Q: IP Intel 显示"查询失败"？
  A: 需要联网访问 ip-api.com；部分校园网/内网环境无外网则无法使用。
     内网 IP 会直接提示无需查询（情报平台查不到内网地址）。

  Q: IP Intel 会暴露内网信息吗？
  A: 不会。只把公网 IP 发给 ip-api.com 查询，不带任何设备信息；
     内网 IP 本地直接拦截，不发请求。

================================================================================
【重新打包 / Rebuild】
================================================================================

  python -m PyInstaller --clean --noconfirm NetworkInspectionV3.spec
  产物: dist/巡检Network Inspection System V3 - For Yata.exe

================================================================================
